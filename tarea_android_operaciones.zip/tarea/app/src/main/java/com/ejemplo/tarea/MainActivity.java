package com.ejemplo.tarea;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText edit1;
    private EditText edit2;
    private TextView tv1;
    // adicionamos
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit1 = (EditText) findViewById(R.id.txt_num1);
        edit2 = (EditText) findViewById(R.id.txt_num2);
        tv1 = (TextView) findViewById(R.id.txt_view1);
        }

    /*Metodo para calcular*/

    public void Calcular(View view) {

        String valor1 = edit1.getText().toString();
        String valor2 = edit2.getText().toString();

        int num1 = Integer.parseInt(valor1);
        int num2 = Integer.parseInt(valor2);
        if (num1 >= num2) {
                int suma = num1 + num2;
                int resta = num1 - num2;
                int multiplicar = num1 * num2;
                int dividir = num1 / num2;
                String resulSuma = String.valueOf(suma);
                String resulResta = String.valueOf(resta);
                String resulMulti = String.valueOf(multiplicar);
                String resulDividir = String.valueOf(dividir);
                tv1.setText("la suma es : " + resulSuma + "\n la resta es: " + resulResta + "\n la multiplicacion es : " + resulMulti + " \n la division es: " + resulDividir);
            }else {
                int suma = num1 + num2;
                int multiplicar = num1 * num2;
                String resulSuma = String.valueOf(suma);
                String resulMulti = String.valueOf(multiplicar);
                tv1.setText("no se puede restar ni dividir \n la suma es : " + resulSuma + "\n la multiplicacion es : " + resulMulti);
     }
            }
        }